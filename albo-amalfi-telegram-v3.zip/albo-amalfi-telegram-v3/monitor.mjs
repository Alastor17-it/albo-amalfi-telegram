import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import { chromium } from 'playwright';

const ALBO_URL = 'https://cittaamalfi.soluzionipa.it/openweb/albo/albo_pretorio.php';
const STATE_FILE = new URL('./state.json', import.meta.url);
const TELEGRAM_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || '';
const MAX_LOAD_MORE = 20;
const ERROR_COOLDOWN_MS = 12 * 60 * 60 * 1000;

const KEYWORDS_HIGH = [
  'debito fuori bilancio', 'veolia', 'pnrr', 'appalto', 'gara', 'affidamento',
  'incarico', 'lavori pubblici', 'urbanistica', 'edilizia', 'scuola', 'demanio',
  'porto', 'depurazione', 'bilancio', 'variazione', 'finanziamento'
];

const KEYWORDS_MEDIUM = [
  'liquidazione', 'spesa', 'turismo', 'evento', 'manifestazione', 'cultura',
  'contributo', 'parcheggio', 'mobilità', 'rifiuti', 'ordinanza', 'delibera',
  'determinazione'
];

function clean(s = '') {
  return String(s).replace(/\s+/g, ' ').trim();
}

function escapeHtml(s = '') {
  return String(s)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function classify(text = '') {
  const t = text.toLowerCase();
  const high = KEYWORDS_HIGH.filter(k => t.includes(k));
  const medium = KEYWORDS_MEDIUM.filter(k => t.includes(k));
  if (high.length) return { label: '🚨 PRIORITÀ MCA', hits: [...high, ...medium] };
  if (medium.length >= 2) return { label: '🟠 DA LEGGERE', hits: medium };
  if (medium.length === 1) return { label: '🟡 Interesse possibile', hits: medium };
  return { label: '⚪ Ordinario', hits: [] };
}

async function telegram(text) {
  if (!TELEGRAM_TOKEN || !TELEGRAM_CHAT_ID) {
    console.log('[telegram non configurato]\n' + text.replace(/<[^>]+>/g, ''));
    return false;
  }

  const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      chat_id: TELEGRAM_CHAT_ID,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: true
    })
  });

  if (!response.ok) {
    throw new Error(`Telegram ${response.status}: ${await response.text()}`);
  }
  return true;
}

async function loadState() {
  try {
    const state = JSON.parse(await fs.readFile(STATE_FILE, 'utf8'));
    return {
      initialized: Boolean(state.initialized),
      seen: Array.isArray(state.seen) ? state.seen.map(String) : [],
      lastErrorFingerprint: state.lastErrorFingerprint || null,
      lastErrorNotifiedAt: state.lastErrorNotifiedAt || null
    };
  } catch {
    return {
      initialized: false,
      seen: [],
      lastErrorFingerprint: null,
      lastErrorNotifiedAt: null
    };
  }
}

async function writeState(state) {
  const out = {
    initialized: Boolean(state.initialized),
    seen: [...new Set(state.seen.map(String))].slice(-5000),
    lastErrorFingerprint: state.lastErrorFingerprint || null,
    lastErrorNotifiedAt: state.lastErrorNotifiedAt || null
  };
  await fs.writeFile(STATE_FILE, JSON.stringify(out, null, 2) + '\n');
}

function errorFingerprint(message) {
  return crypto.createHash('sha256').update(clean(message)).digest('hex').slice(0, 16);
}

function extractAlboNumber(text) {
  return clean(text).match(/\b20\d{2}\/\d{5,}\b/)?.[0] || '';
}

function extractDate(text) {
  return clean(text).match(/\b\d{2}\/\d{2}\/20\d{2}\b/)?.[0] || '';
}

function extractSubject(listText, detailText) {
  const candidates = [detailText, listText].map(clean);
  for (const s of candidates) {
    const match = s.match(/(?:Oggetto|OGGETTO)\s*[:\-]?\s*(.{12,1100}?)(?=\s+(?:Ufficio|Tipo|Data|Numero|Nr\.|Pubblicazione|Affissione|Allegati|Registro)\b|$)/i);
    if (match) return clean(match[1]).slice(0, 900);
  }
  return clean(listText).slice(0, 900);
}

function stableDetailUrl(id) {
  return `${ALBO_URL}#atto-${encodeURIComponent(id)}`;
}

async function loadAllCurrentActs(page) {
  await page.goto(ALBO_URL, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(2500);

  const sample = `${await page.title()} ${(await page.content()).slice(0, 6000)}`;
  if (/403|forbidden|access denied/i.test(sample)) {
    throw new Error('Il portale ha risposto con 403/anti-bot');
  }

  await page.waitForSelector('a[href*="albo_dettagli.php?id="]', { timeout: 30000 });

  // Il portale usa caricamento progressivo. Proviamo a espandere tutto l'Albo corrente,
  // così anche una pubblicazione massiva non ci fa perdere atti.
  for (let i = 0; i < MAX_LOAD_MORE; i++) {
    const button = page.getByText(/carica altri/i).first();
    if (!(await button.count())) break;
    if (!(await button.isVisible().catch(() => false))) break;

    const before = await page.locator('a[href*="albo_dettagli.php?id="]').count();
    await button.click().catch(() => null);
    await page.waitForTimeout(1000);
    const after = await page.locator('a[href*="albo_dettagli.php?id="]').count();
    if (after <= before) break;
  }

  return await page.locator('a[href*="albo_dettagli.php?id="]').evaluateAll((links) => {
    const seen = new Set();
    const acts = [];

    for (const a of links) {
      let url;
      try { url = new URL(a.href); } catch { continue; }
      const id = url.searchParams.get('id');
      if (!id || seen.has(id)) continue;
      seen.add(id);

      const container = a.closest('tr') || a.closest('article') || a.closest('.row') || a.parentElement;
      const text = (container?.innerText || a.innerText || '').replace(/\s+/g, ' ').trim();
      acts.push({ id, href: a.href, listText: text });
    }

    return acts;
  });
}

async function readDetail(context, act) {
  const page = await context.newPage();
  try {
    await page.goto(act.href, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(800);
    return await page.evaluate(() => {
      const text = (document.body?.innerText || '').replace(/\s+/g, ' ').trim();
      const attachments = [...document.querySelectorAll('a[href*="/openweb/portal/doc.php?"]')]
        .map(a => ({
          text: (a.innerText || '').replace(/\s+/g, ' ').trim(),
          href: a.href
        }));
      return { text, attachments };
    });
  } finally {
    await page.close();
  }
}

async function notifyAct(context, act) {
  let detail = { text: '', attachments: [] };
  try {
    detail = await readDetail(context, act);
  } catch (error) {
    console.warn(`Dettaglio ${act.id} non leggibile: ${error.message}`);
  }

  const fullText = `${act.listText} ${detail.text}`;
  const subject = extractSubject(act.listText, detail.text);
  const classification = classify(fullText);
  const alboNumber = extractAlboNumber(fullText);
  const date = extractDate(fullText);

  const lines = [
    '🔔 <b>NUOVO ATTO – ALBO PRETORIO AMALFI</b>',
    '',
    `<b>${classification.label}</b>`,
    alboNumber ? `📄 <b>${escapeHtml(alboNumber)}</b>` : `📄 ID interno ${escapeHtml(act.id)}`,
    date ? `📅 ${escapeHtml(date)}` : '',
    '',
    `<b>${escapeHtml(subject)}</b>`,
    '',
    `📎 Allegati rilevati: ${detail.attachments.length}`,
    classification.hits.length ? `🔎 Parole chiave: ${escapeHtml([...new Set(classification.hits)].join(', '))}` : '',
    '',
    `🌐 <a href="${escapeHtml(ALBO_URL)}">Apri l'Albo Pretorio</a>`
  ].filter(Boolean);

  await telegram(lines.join('\n'));
}

async function main() {
  const state = await loadState();
  const browser = await chromium.launch({
    headless: true,
    args: ['--disable-blink-features=AutomationControlled', '--no-sandbox']
  });

  const context = await browser.newContext({
    locale: 'it-IT',
    timezoneId: 'Europe/Rome',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
    viewport: { width: 1365, height: 900 },
    extraHTTPHeaders: {
      'Accept-Language': 'it-IT,it;q=0.9,en;q=0.7'
    }
  });

  try {
    const page = await context.newPage();
    const acts = await loadAllCurrentActs(page);
    await page.close();

    if (!acts.length) throw new Error('Nessun atto trovato: parser o portale da verificare');
    console.log(`Atti correnti rilevati: ${acts.length}`);

    const currentIds = acts.map(a => a.id);

    if (!state.initialized) {
      state.initialized = true;
      state.seen = currentIds;
      state.lastErrorFingerprint = null;
      state.lastErrorNotifiedAt = null;
      await writeState(state);
      await telegram(
        `✅ <b>Monitor Albo Pretorio Amalfi attivato</b>\n\n` +
        `Baseline creata con <b>${acts.length}</b> atti correnti.\n` +
        `Da ora segnalerò solo le nuove pubblicazioni.`
      );
      console.log('Baseline iniziale salvata.');
      return;
    }

    const seen = new Set(state.seen);
    const fresh = acts.filter(a => !seen.has(a.id)).reverse();
    console.log(`Nuovi atti: ${fresh.length}`);

    for (const act of fresh) {
      await notifyAct(context, act);
      seen.add(act.id);
    }

    // Scriviamo state.json solo quando serve. Niente 48 commit al giorno per dire "nessuna novità".
    const errorWasSet = Boolean(state.lastErrorFingerprint || state.lastErrorNotifiedAt);
    if (fresh.length || errorWasSet) {
      state.seen = [...seen];
      state.lastErrorFingerprint = null;
      state.lastErrorNotifiedAt = null;
      await writeState(state);
    }
  } catch (error) {
    const message = String(error?.message || error);
    console.error(error);

    const fingerprint = errorFingerprint(message);
    const last = state.lastErrorNotifiedAt ? Date.parse(state.lastErrorNotifiedAt) : 0;
    const sameError = state.lastErrorFingerprint === fingerprint;
    const cooldownPassed = !last || Date.now() - last >= ERROR_COOLDOWN_MS;

    if (!sameError || cooldownPassed) {
      try {
        await telegram(
          `⚠️ <b>Monitor Albo Amalfi: errore</b>\n\n` +
          `${escapeHtml(message)}\n\n` +
          `Non invierò lo stesso errore di nuovo per 12 ore.`
        );
      } catch (telegramError) {
        console.error('Errore anche nell\'invio Telegram:', telegramError);
      }
      state.lastErrorFingerprint = fingerprint;
      state.lastErrorNotifiedAt = new Date().toISOString();
      await writeState(state);
    }

    process.exitCode = 1;
  } finally {
    await browser.close();
  }
}

await main();
