# Albo Pretorio Amalfi → Telegram

Monitor automatico dell'Albo Pretorio del Comune di Amalfi.

**Sito monitorato:**  
https://cittaamalfi.soluzionipa.it/openweb/albo/albo_pretorio.php

## Cosa fa

- controlla l'Albo ogni **30 minuti**;
- usa Chromium/Playwright, perché il portale usa sessione e token CSRF dinamici;
- carica progressivamente gli atti correnti, non soltanto i primi 15;
- identifica ogni pubblicazione tramite l'`id` interno del dettaglio;
- alla prima esecuzione crea una **baseline** e non invia tutti gli atti vecchi;
- nelle esecuzioni successive manda su Telegram soltanto gli atti nuovi;
- rileva il numero di allegati;
- evidenzia alcune parole chiave utili al monitoraggio civico;
- evita di inviare lo stesso errore ogni mezz'ora;
- aggiorna `state.json` soltanto quando serve, quindi non crea commit inutili a ogni controllo.

## Repository consigliato

Se vuoi mantenere il controllo ogni 30 minuti senza consumare la normale quota mensile di minuti dei repository privati, usa un **repository pubblico**. I Secrets di GitHub Actions non vengono pubblicati nel repository.

Se preferisci un repository privato, controlla la quota Actions disponibile sul tuo piano.

## I due Secrets da inserire

Apri:

`Settings → Secrets and variables → Actions → New repository secret`

Crea esattamente questi due Secrets:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

Non mettere token o chat ID nei file del repository.

## Prima attivazione

1. Inserisci i due Secrets.
2. Apri `Actions`.
3. Seleziona **Albo Pretorio Amalfi → Telegram**.
4. Premi **Run workflow**.
5. La prima esecuzione crea la baseline degli atti già presenti.
6. Su Telegram riceverai il messaggio di attivazione.
7. Da quel momento vengono notificati soltanto i nuovi atti.

## Nota sul 403

Il portale SoluzionePA applica protezioni anti-bot. Il monitor usa un browser reale proprio per ridurre questo problema.

Se i runner GitHub venissero comunque bloccati stabilmente, nei log apparirà:

`Il portale ha risposto con 403/anti-bot`

In quel caso sarà necessario spostare l'esecuzione su una macchina/rete italiana o su un runner self-hosted. Il codice e la logica del monitor restano gli stessi.

## Stato

`state.json` contiene soltanto gli ID degli atti già visti e lo stato degli eventuali errori. Non contiene credenziali.
